function salida = tasaCrucesxCero(tramas, ventana)
    salida = zeros(1,size(tramas,2));
    tamTrama = size(tramas,1);
    if strcmp(ventana,'hamming')
        v=hamming(tamTrama);
    elseif strcmp(ventana,'hanning')
        v=hanning(tamTrama);
    else
        v=rectwin(tamTrama);
    end
    
    for i = 1:size(tramas,2)
        salida(i) = sum(abs(sign(tramas(2:end,i)) - sign(tramas(1:end-1,i)))/2) / tamTrama;
    end
end