function e = logEnergia(tramas, ventana)
    e = log(energia(tramas,ventana));
end