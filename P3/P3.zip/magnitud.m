function salida = magnitud(tramas, ventana)
    salida = sum(enventanado(abs(tramas), ventana));
end