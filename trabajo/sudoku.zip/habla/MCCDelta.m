function deltaCoefMel = MCCDelta (coefMel, longVentanaDelta)
    deltaCoefMel = audioDelta(coefMel, longVentanaDelta);
end

